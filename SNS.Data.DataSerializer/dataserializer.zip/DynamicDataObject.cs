﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Linq.Expressions;
using SNS.Data.DataSerializer.DataExtensions;

namespace SNS.Data.DataSerializer
{
    public abstract class DynamicDataObject
    {

    }
}
