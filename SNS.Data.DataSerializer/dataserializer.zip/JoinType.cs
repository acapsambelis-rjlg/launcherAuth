﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNS.Data.DataSerializer
{
    public enum JoinType
    {
        RIGHT = 0x00,
        INNER = 0X01,
        LEFT = 0X02
    }
}
