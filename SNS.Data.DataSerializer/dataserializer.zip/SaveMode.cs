﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNS.Data.DataSerializer
{
    public enum SaveMode
    {
        Create = 0x00,
        Update = 0x01
    }
}
